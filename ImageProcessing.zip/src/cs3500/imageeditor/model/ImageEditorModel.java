package cs3500.imageeditor.model;

/**
 * This interface represents the operation offered by the ImageEditor model.
 */
public interface ImageEditorModel {

  /**
   * returns the pixel at the specified location.
   *
   * @param row the row number of the pixel
   * @param col the column number of the pixel
   * @return a pixel which has the RGB components
   */
  Pixel getPixelAt(int col, int row);

  /**
   * returns the height of the image.
   *
   * @return the height of the image
   */
  int getHeight();

  /**
   * returns the width of the image.
   *
   * @return width of the image
   */
  int getWidth();

}
